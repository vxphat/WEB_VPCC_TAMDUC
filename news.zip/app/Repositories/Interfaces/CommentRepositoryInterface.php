<?php

namespace App\Repositories\Interfaces;

/**
 * Interface CommentRepositoryInterface
 * @package App\Services\Interfaces
 */
interface CommentRepositoryInterface
{
    
}
