<?php
return [
    'publish' => [
        '0' => 'Chọn tình trạng',
        '1' => 'Không kích hoạt',
        '2' => 'Kích hoạt',
    ],

    

    'search' => 'Tìm kiếm',
    'searchInput' => 'Nhập thông tin tìm kiếm..',
    'perpage' => 'bản ghi',

    'defaultPublish' => ['publish', '=', 2],
];