<?php

namespace App\Services\Interfaces;

/**
 * Interface CommentServiceInterface
 * @package App\Services\Interfaces
 */
interface CommentServiceInterface
{

}
